#include "ros/ros.h"
#include "tf2_ros/buffer.h"
#include "tf2_ros/transform_listener.h"
#include "geometry_msgs/PointStamped.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"

int main(int argc, char  *argv[])
{
    setlocale(LC_ALL,"");
    ros::init(argc,argv,"tf_dynamic_sub");
    ros::NodeHandle nh;

    tf2_ros::Buffer buffer;             //创建buffer对象，用来存储listener接受到的坐标信息
    tf2_ros::TransformListener listener(buffer);        //创建listener对象，并将接收到的信息传入到buffer中

    ros::Rate rate(1);          //设置接收频率

    while (ros::ok())
    {
        //生成一个坐标点（相对于子级坐标系）
        geometry_msgs::PointStamped p;
        p.header.frame_id="turtle1";          //坐标点位于哪个坐标系
        p.header.stamp=ros::Time();            //坐标点时间戳
        p.point.x=2;
        p.point.y=3;
        p.point.z=4;                //坐标点相对于坐标系的坐标


        //使用try结构防止出现抛出异常，即防止在pub的坐标系未发布前就开始接收消息
        try
        {
            //接收代码
            geometry_msgs::PointStamped p2;             //创建一个点p2接收点p转换后的坐标
            p2=buffer.transform(p,"world");             //转换的核心实现，传入两个参数，
                                                                                                    //第一个参数是转换前的坐标，第二个参数是转换后相对的坐标系，
                                                                                                    //同时需要包含头文件#include "tf2_geometry_msgs/tf2_geometry_msgs.h"
            ROS_INFO("转换后的坐标点为：%.2f,%.2f,%.2f,相对的坐标系是:%s",p2.point.x,p2.point.y,p2.point.z,p2.header.frame_id.c_str());
        }
        catch(const std::exception& e)
        {
            ROS_INFO("%s",e.what());
        }
        rate.sleep();
        ros::spinOnce();
    }
    return 0;
}