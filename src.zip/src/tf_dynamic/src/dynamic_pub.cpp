#include "ros/ros.h"
#include "turtlesim/Pose.h"
#include "tf2_ros/transform_broadcaster.h"
#include "geometry_msgs/Transform.h"
#include "tf2/LinearMath/Quaternion.h"

/*
    该节点订阅小海龟的位姿信息，并且将位姿信息发布
*/

void doPose(const turtlesim::Pose::ConstPtr & pose){
    static tf2_ros::TransformBroadcaster broadcaster;           //创建tf广播器
    geometry_msgs::TransformStamped tfs;                  //创建广播的数据

    //编写广播的数据
    tfs.header.frame_id="world";
    tfs.header.stamp=ros::Time::now();

    tfs.child_frame_id="turtle1";

    tfs.transform.translation.x=pose->x;
    tfs.transform.translation.y=pose->y;
    tfs.transform.translation.z=0;

    //四元数设置
    tf2::Quaternion qtn(0,0,pose->theta);
    tfs.transform.rotation.x=qtn.getX();
    tfs.transform.rotation.y=qtn.getY();
    tfs.transform.rotation.z=qtn.getZ();
    tfs.transform.rotation.w=qtn.getW();

    broadcaster.sendTransform(tfs);


    

}

int main(int argc, char  *argv[])
{
    setlocale(LC_ALL,"");
    ros::init(argc,argv,"tf_dynamic_pub");
    ros::NodeHandle nh;
    ros::Subscriber sub=nh.subscribe("turtle1/pose",100,doPose);            //订阅小海龟的位姿信息
    ros::spin();                //回调函数

    return 0;
}
