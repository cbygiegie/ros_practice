#include "ros/ros.h"
#include "rosbag/bag.h"
#include "std_msgs/String.h"
#include "rosbag/view.h"
#include "std_msgs/Int32.h"

int main(int argc, char  *argv[])
{
    setlocale(LC_ALL,"");
    ros::init(argc,argv,"rosbag_read");
    ros::NodeHandle nh;

    //创建bag对象
    rosbag::Bag bag;

    //打开
    bag.open("hello.bag",rosbag::BagMode::Read);
    
    //读
    for (auto &&m : rosbag::View(bag))
    {
        std_msgs::String::ConstPtr p = m.instantiate<std_msgs::String>();
        if(p != nullptr){
            ROS_INFO("读取的数据:%s",p->data.c_str());
        }
    }
    
    
    

    //关闭
    bag.close();

    return 0;
}
