#include "ros/ros.h"
#include "tf2_ros/transform_listener.h"
#include "tf2_ros/buffer.h"

int main(int argc, char  *argv[])
{
    setlocale(LC_ALL,"");
    ros::init(argc,argv,"tf_multi_sub");
    ros::NodeHandle nh;
    tf2_ros::Buffer buffer;
    tf2_ros::TransformListener listener(buffer);

    ros::Rate rate(1);

    while(ros::ok()){
        
        try
        {
            //坐标系 1原点相对于坐标系2的坐标
        geometry_msgs::TransformStamped tfs=buffer.lookupTransform("son1","son2",ros::Time(0));
        ROS_INFO("son1相对于son2的坐标关系: 父坐标系是：%s,子坐标系是：%s,son1在son2中的位置是:(%.2f,%.2f,%.2f)",tfs.header.frame_id.c_str(),tfs.child_frame_id.c_str(),tfs.transform.translation.x,tfs.transform.translation.y,tfs.transform.translation.z);

        }
        catch(const std::exception& e)
        {
            ROS_INFO("错误信息是：%s",e.what());
        }
        
    
        rate.sleep();
        ros::spinOnce();
    }

    return 0;
}
