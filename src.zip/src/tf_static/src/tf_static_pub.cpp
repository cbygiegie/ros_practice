#include "ros/ros.h"
#include "tf2_ros/static_transform_broadcaster.h"
#include "geometry_msgs/TransformStamped.h"
#include "tf2/LinearMath/Quaternion.h"

int main(int argc, char  *argv[])
{
    setlocale(LC_ALL,"");
    ros::init(argc,argv,"static_broadcast");            //初始化ros节点
    ros::NodeHandle nh;         //可以不要
    tf2_ros::StaticTransformBroadcaster broadcaster;            //创建静态坐标转换广播器
    geometry_msgs::TransformStamped ts;                 //创建坐标系信息

    //设置头信息
    ts.header.seq=100;
    ts.header.frame_id="base_link";
    ts.header.stamp=ros::Time::now();

    //设置子级坐标系
    ts.child_frame_id="laser";

    //设置子级相对父级偏移量
    ts.transform.translation.x=0.2;
    ts.transform.translation.y=0;
    ts.transform.translation.z=0.5;

    //设置四元数，将欧拉数转换为四元数
    tf2::Quaternion qtn;
    qtn.setRPY(0,0,0);
    ts.transform.rotation.x=qtn.getX();
    ts.transform.rotation.y=qtn.getY();
    ts.transform.rotation.z=qtn.getZ();
    ts.transform.rotation.w=qtn.getW();

    //广播器发布坐标信息
    broadcaster.sendTransform(ts);
    ros::spin();
    






    return 0;
}
